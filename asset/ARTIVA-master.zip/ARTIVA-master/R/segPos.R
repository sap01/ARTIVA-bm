segPos <-
function(CPvector, n){
  pos = which(CPvector==n)
  return(pos)
}
